from .models import Dht11
from .serializers import DHT11serialize
from rest_framework.decorators import api_view
from rest_framework import status
from rest_framework.response import Response
from django.core.mail import send_mail
from django.conf import settings
from twilio.rest import Client
import requests
# Définir la fonction pour envoyer des messages Telegram
def send_telegram_message(token, chat_id, message):
    url = f"https://api.telegram.org/bot{token}/sendMessage"
    payload = {
        'chat_id': chat_id,
        'text': message
    }
    response = requests.post(url, data=payload)
    return response
@api_view(["GET", "POST"])
def Dlist(request):
    if request.method == "GET":
        all_data = Dht11.objects.all()
        data_ser = DHT11serialize(all_data, many=True)  # Les données sont sérialisées en JSON
        return Response(data_ser.data)

    elif request.method == "POST":
        serial = DHT11serialize(data=request.data)
        print("aa")
        if serial.is_valid():
            print("aa1")
            serial.save()
            derniere_temperature = Dht11.objects.last().temp
            print(derniere_temperature)

            if derniere_temperature > 25:
                print("aa2")
                subject = 'Alerte'
                message = f'La température dépasse le seuil de 25°C, veuillez intervenir immédiatement pour vérifier et corriger cette situation'
                email_from = settings.EMAIL_HOST_USER
                recipient_list = ['fatmiayoub17@gmail.com']
                send_mail(subject, message, email_from, recipient_list)
                print("aaa")

                # Alert WhatsApp
                account_sid = 'AC4cd5f5fffa11d2e43ca41341044b907c'
                auth_token = 'cc2d0186cd97185b25c49caaf993569b'
                client = Client(account_sid, auth_token)

                message_whatsapp = client.messages.create(
                    from_='whatsapp:+14155238886',
                    body='La température dépasse le seuil de 25°C, veuillez intervenir immédiatement pour vérifier et corriger cette situation',
                    to='whatsapp:+212653984613'
                )
                print("aaa1")

                # Alert Telegram
                telegram_token = '7963201295:AAEKAuwaFyPFahILyAp5Z7oPIu2-FJXO_a8'
                chat_id = '1639421512'  # Remplacez par votre ID de chat
                telegram_message = 'La température dépasse le seuil de 25°C, veuillez intervenir immédiatement pour vérifier et corriger cette situation'
                send_telegram_message(telegram_token, chat_id, telegram_message)
                print("aaa2")
                return Response(serial.data, status=status.HTTP_201_CREATED)

            # else:
            #     return Response(serial.errors, status=status.HTTP_400_BAD_REQUEST)